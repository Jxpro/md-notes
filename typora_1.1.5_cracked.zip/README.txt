1.官网下载安装包：https://download.typora.io/windows/typora-setup-x64-1.1.5.exe
2.使用当前目录下 app.asar  替换 typora 安装目录下的 resources\app.asar 
（如：D:\Program Files\Typora\resources\app.asar）
3.点击激活，邮箱随意填，序列号如下：5FRAE5-729EH2-XY9H8A-PAXCCS


Cracked by Joker Xin
Based on typoraCracker(https://github.com/Mas0nShi/typoraCracker)